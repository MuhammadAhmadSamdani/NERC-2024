#ifndef _BLUEGRID6_H_
#define _BLUEGRID6_H_

void blue_grid6();

#endif // _BLUEGRID6 _H_