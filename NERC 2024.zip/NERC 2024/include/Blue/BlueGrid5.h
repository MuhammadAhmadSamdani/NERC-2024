#ifndef _BLUEGRID5_H_
#define _BLUEGRID5_H_

void blue_grid5();

#endif // _BLUEGRID5 _H_