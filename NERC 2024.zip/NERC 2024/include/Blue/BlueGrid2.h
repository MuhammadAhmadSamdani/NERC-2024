#ifndef _BLUEGRID2_H_
#define _BLUEGRID2_H_

void blue_grid2();

#endif // _BLUEGRID2_H_