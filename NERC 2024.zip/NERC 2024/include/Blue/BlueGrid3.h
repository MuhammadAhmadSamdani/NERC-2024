#ifndef _BLUEGRID3_H_
#define _BLUEGRID3_H_

void blue_grid3();

#endif // _BLUEGRID3 _H_