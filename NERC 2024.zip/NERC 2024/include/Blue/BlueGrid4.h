#ifndef _BLUEGRID4_H_
#define _BLUEGRID4_H_

void blue_grid4();

#endif // _BLUEGRID4 _H_