#ifndef _BLUEGRID10_H_
#define _BLUEGRID10_H_

void blue_grid10();

#endif // _BLUEGRID10_H_