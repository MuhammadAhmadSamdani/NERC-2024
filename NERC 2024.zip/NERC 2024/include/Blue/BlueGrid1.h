#ifndef _BLUEGRID1_H_
#define _BLUEGRID1_H_

void blue_grid1();

#endif // _BLUEGRID1_H_