#ifndef _BLUEGRID7_H_
#define _BLUEGRID7_H_

void blue_grid7();

#endif // _BLUEGRID7_H_