#ifndef _BLUEGRID9_H_
#define _BLUEGRID9_H_

void blue_grid9();

#endif // _BLUEGRID9 _H_