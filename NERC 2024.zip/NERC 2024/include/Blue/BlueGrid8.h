#ifndef _BLUEGRID8_H_
#define _BLUEGRID8_H_

void blue_grid8();

#endif // _BLUEGRID8 _H_