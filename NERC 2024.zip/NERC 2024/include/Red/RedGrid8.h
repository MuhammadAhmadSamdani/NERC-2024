#ifndef _REDGRID8_H_
#define _REDGRID8_H_

void red_grid8();

#endif // _REdGRID8 _H_