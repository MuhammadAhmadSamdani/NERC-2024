#ifndef _REDGRID3_H_
#define _REDGRID3_H_

void red_grid3();

#endif // _REDGRID3_H_