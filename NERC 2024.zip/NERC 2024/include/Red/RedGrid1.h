#ifndef _REDGRID1_H_
#define _REDGRID1_H_

void red_grid1();

#endif // _REDGRID1_H_