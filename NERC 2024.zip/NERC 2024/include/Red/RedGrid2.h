#ifndef _REDGRID2_H_
#define _REDGRID2_H_

void red_grid2();

#endif // _REDGRID2_H_