#ifndef _REDGRID6_H_
#define _REDGRID6_H_

void red_grid6();

#endif // _REDGRID6 _H_