#ifndef _REDGRID4_H_
#define _REDGRID4_H_

void red_grid4();

#endif // _REDGRID4_H_