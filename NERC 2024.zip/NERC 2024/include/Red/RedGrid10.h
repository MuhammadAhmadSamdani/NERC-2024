#ifndef _REDGRID10_H_
#define _REDGRID10_H_

void red_grid10();

#endif // _REdGRID10 _H_