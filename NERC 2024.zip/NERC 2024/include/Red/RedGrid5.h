#ifndef _REDGRID5_H_
#define _REDGRID5_H_

void red_grid5();

#endif // _REDGRID5_H_
