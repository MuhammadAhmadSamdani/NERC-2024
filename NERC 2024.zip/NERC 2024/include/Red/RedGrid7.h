#ifndef _REDGRID7_H_
#define _REDGRID7_H_

void red_grid7();

#endif // _REDGRID7 _H_